
	
INSERT INTO ARTICLE VALUES
	('PU3','PULL IMT',40.00,147,'Le sweatshirt capuche : un classique mais une valeur sure !','pull3.PNG'),
	('PU2','PULL IMT COL ROND',35.50,301,'Le pull col rond : une nouveaute sur le campus certes, mais une nouveaute tchatcheuse !','pull2.PNG');