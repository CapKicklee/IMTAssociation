package db.dao;

import db.mapper.Mappable;

/**
 * Représentation objet de la base de données
 * @author Juliette FRETAY, Kendall FOREST, Chloé GUILBAUD
 */
public interface DAO extends Mappable {}
