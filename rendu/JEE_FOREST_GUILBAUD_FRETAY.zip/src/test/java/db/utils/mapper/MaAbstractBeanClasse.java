package db.utils.mapper;

public abstract class MaAbstractBeanClasse extends MaBeanClasse {

    public MaAbstractBeanClasse(String attr1, Integer attr2) {
        super(attr1, attr2);
    }
}
